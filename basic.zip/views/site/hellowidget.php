<?php
use app\module\comment\widgets\Cmtwidget;
?>
<?= Cmtwidget::widget(['message' => ' Yii2.0']) ?>
