<div class="main_content">
    <?php echo $this->render('comment');?>
</div>
